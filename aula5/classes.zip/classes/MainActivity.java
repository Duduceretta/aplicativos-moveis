package com.example.exemplocrud1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.Manifest;
import java.io.ByteArrayOutputStream;

/**
 * MainActivity: A Controller da nossa aplicação.
 * Responsável por gerenciar a interface do usuário (UI) e a interação com o usuário.
 */
public class MainActivity extends AppCompatActivity {
    private EditText nome;
    private EditText cpf;
    private EditText telefone;
    private EditText endereco;
    private EditText curso;
    private Aluno aluno = null;
    private ImageView imageView;
    private static final int CAMERA_PERMISSION_CODE = 100;
    private static final int REQUEST_IMAGE_CAPTURE = 200;

    // Objeto de persistência (Data Access Object)
    private AlunoDao dao;

    /**
     * onCreate: Primeiro método do Ciclo de Vida (Lifecycle) a ser executado.
     * Aqui é onde a interface é "inflada" e os objetos são instanciados.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Define qual arquivo XML será o layout desta tela
        setContentView(R.layout.activity_main);

        // Vinculando os componentes do XML com as variáveis Java (ID deve ser igual ao do XML)
        nome = findViewById(R.id.editNome);
        cpf = findViewById(R.id.editCPF);
        telefone = findViewById(R.id.editTelefone);
        endereco = findViewById(R.id.editEndereco);
        curso = findViewById(R.id.editCurso);
        imageView = findViewById(R.id.imageView);

        Button btnTakePhoto = findViewById(R.id.btnTakePhoto);

        // Instanciando o DAO. Passamos 'this' (a própria Activity) como Contexto.
        // O Contexto é necessário para o SQLite saber em que pasta do sistema salvar o arquivo.
        dao = new AlunoDao(this);

        Intent it = getIntent(); //pega intenção
        if(it.hasExtra("aluno")){
            aluno = (Aluno) it.getSerializableExtra("aluno");
            nome.setText(aluno.getNome());
            cpf.setText(aluno.getCpf());
            telefone.setText(aluno.getTelefone());
            endereco.setText(aluno.getEndereco()); // CORRIGIDO: Preenche endereço
            curso.setText(aluno.getCurso());       // CORRIGIDO: Preenche curso

            byte[] fotoBytes = aluno.getFotoBytes();
            if (fotoBytes != null && fotoBytes.length > 0) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);
                imageView.setImageBitmap(bitmap);
            }
        }
    }

    public void salvar(View view) {

        String nomeDigitado = nome.getText().toString().trim();
        String cpfDigitado = cpf.getText().toString().trim();
        String telefoneDigitado = telefone.getText().toString().trim();
        String enderecoDigitado = endereco.getText().toString().trim();
        String cursoDigitado = curso.getText().toString().trim();

        if (nomeDigitado.isEmpty() || cpfDigitado.isEmpty() || telefoneDigitado.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validação do CPF
        System.out.println("CPF antes da validação: " + cpfDigitado);
        if (!dao.validaCpf(cpfDigitado)) {
            Toast.makeText(this, "CPF inválido. Digite novamente.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verifica se é um NOVO cadastro:
        // É novo se a variável for nula OU se a variável existe (tirou foto) mas não tem ID salvo no banco.
        boolean inserindoNovo = (aluno == null || aluno.getId() == null);

        // Bloqueia se for um CPF duplicado no banco (ignorando se ele estiver editando o próprio aluno)
        if (inserindoNovo || !cpfDigitado.equals(aluno.getCpf())) {
            if (dao.cpfExistente(cpfDigitado)) {
                Toast.makeText(this, "CPF duplicado. Insira um CPF diferente.", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Validação do Telefone
        if (!dao.validaTelefone(telefoneDigitado)) {
            Toast.makeText(this, "Telefone inválido! Use o formato correto: (XX) 9XXXX-XXXX", Toast.LENGTH_SHORT).show();
            return;
        }

        // --- HORA DE SALVAR NO BANCO ---

        if (inserindoNovo) {
            // Se não tem foto e o aluno tá nulo, cria um novo
            if (aluno == null) {
                aluno = new Aluno();
            }

            aluno.setNome(nomeDigitado);
            aluno.setCpf(cpfDigitado);
            aluno.setTelefone(telefoneDigitado);
            aluno.setEndereco(enderecoDigitado); // CORRIGIDO: Agora salva o endereço!
            aluno.setCurso(cursoDigitado);       // CORRIGIDO: Agora salva o curso!

            // Inserir aluno no banco de dados
            long id = dao.inserir(aluno);
            if (id != -1) {
                Toast.makeText(this, "Aluno inserido com sucesso!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao inserir aluno. Tente novamente.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Atualização de um aluno existente
            aluno.setNome(nomeDigitado);
            aluno.setCpf(cpfDigitado);
            aluno.setTelefone(telefoneDigitado);
            aluno.setEndereco(enderecoDigitado); // CORRIGIDO
            aluno.setCurso(cursoDigitado);       // CORRIGIDO

            dao.atualizar(aluno);
            Toast.makeText(this, "Aluno atualizado com sucesso!", Toast.LENGTH_SHORT).show();
        }

        nome.setText("");
        cpf.setText("");
        telefone.setText("");
        endereco.setText("");
        curso.setText("");
        imageView.setImageResource(R.mipmap.ic_launcher);
        aluno = null;
    }

    /**
     * Método chamado pelo clique do botão "Tirar Foto" (android:onClick no XML).
     * Sua principal função é verificar se o usuário já permitiu o uso da câmera.
     */
    public void tirarFoto(View view) {
        // Verifica se a permissão de CAMERA já foi concedida anteriormente
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Se NÃO tem permissão, abre a janelinha do sistema pedindo a autorização.
            // O código CAMERA_PERMISSION_CODE (100) serve para identificarmos esta resposta depois.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        } else {
            // Se JÁ tem permissão, chama o método para abrir a câmera de fato.
            startCamera();
        }
    }

    /**
     * Método chamado automaticamente após o usuário responder à solicitação de permissão.
     * @param requestCode O código (100) que enviamos lá no tirarFoto.
     * @param permissions O array de permissões solicitadas.
     * @param grantResults O resultado (concedido ou negado) para cada permissão.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Verifica se a resposta que chegou é referente ao nosso pedido de câmera (código 100)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            // Verifica se o array de resultados não está vazio e se o usuário clicou em "Permitir"
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("CAMERA_DEBUG", "Usuário permitiu, abrindo câmera...");
                startCamera();
            } else {
                // Se o usuário negou, avisamos que ele não conseguirá tirar fotos.
                Toast.makeText(this, "A permissão é necessária para usar a câmera.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Método auxiliar que cria a "Intenção" de abrir o aplicativo de câmera do dispositivo.
     */
    private void startCamera() {
        try {
            // Cria uma Intent (intenção) para capturar uma imagem.
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Inicia a atividade da câmera esperando um resultado (a foto).
            // O código REQUEST_IMAGE_CAPTURE (200) serve para identificarmos esta foto quando ela voltar.
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } catch (Exception e) {
            Log.e("CAMERA_DEBUG", "Erro ao abrir a câmera: " + e.getMessage());
            Toast.makeText(this, "Erro ao abrir a câmera no seu dispositivo.", Toast.LENGTH_SHORT).show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 1. Verifica se o resultado que está voltando é o da nossa Câmera (código 200)
        // 2. Verifica se a foto foi tirada com sucesso (RESULT_OK)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            // Extrai a imagem compactada (thumbnail) que vem dentro da Intent 'data'
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            // Exibe a foto na tela para o usuário ver
            imageView.setImageBitmap(imageBitmap);
            // --- PREPARAÇÃO PARA O BANCO DE DADOS ---
            // Transforma o Bitmap em um Array de Bytes (byte[]), que é como o SQLite guarda imagens (BLOB)
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            // Se o objeto 'aluno' for nulo (novo cadastro), instanciamos ele aqui para guardar a foto
            if (aluno == null){
                aluno = new Aluno();
            }
            // Guarda os bytes da foto no objeto aluno (será usado no método salvar())
            aluno.setFotoBytes(byteArray);
        }
    }

    public void irParaListar(View view) {
        Intent intent = new Intent(this, ListarAlunosActivity.class);
        startActivity(intent);
    }
}