package com.example.exemplocrud1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class AlunoDao {
    private Conexao conexao;
    private SQLiteDatabase banco;

    public AlunoDao(Context context){
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    /**
     * Método para inserir um novo Aluno no banco de dados.
     * @param aluno Objeto contendo os dados (nome, cpf, telefone)
     * @return Retorna o ID da linha inserida (long) ou -1 em caso de erro.
     */
    public long inserir(Aluno aluno){
        ContentValues values = new ContentValues();

        values.put("nome", aluno.getNome());
        values.put("cpf", aluno.getCpf());
        values.put("telefone", aluno.getTelefone());

        return banco.insert("aluno", null, values);
    }
}
